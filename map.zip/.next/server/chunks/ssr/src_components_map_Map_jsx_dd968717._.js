module.exports = {

"[project]/src/components/map/Map.jsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_leaflet_dist_leaflet-src_21816466.js",
  "server/chunks/ssr/node_modules_next_dist_compiled_9efc75b8._.js",
  "server/chunks/ssr/node_modules_5d713f4e._.js",
  "server/chunks/ssr/[root of the server]__b74d9139._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/map/Map.jsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};