module.exports = {

"[project]/src/components/map/Map.jsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_19c86c47._.js",
  "server/chunks/ssr/src_components_map_Map_jsx_49da6602._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/map/Map.jsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};