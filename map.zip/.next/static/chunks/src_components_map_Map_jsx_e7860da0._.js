(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_map_Map_jsx_e7860da0._.js", {

"[project]/src/components/map/Map.jsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_8d444dc5._.js",
  "static/chunks/src_components_map_Map_jsx_df8be43f._.js",
  {
    "path": "static/chunks/node_modules_leaflet_dist_eeb49e3b._.css",
    "included": [
      "[project]/node_modules/leaflet/dist/images/layers.png (static in css)",
      "[project]/node_modules/leaflet/dist/images/layers-2x.png (static in css)",
      "[project]/node_modules/leaflet/dist/images/marker-icon.png (static in css)",
      "[project]/node_modules/leaflet/dist/leaflet.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/node_modules_leaflet_dist_images_layers_png_ba3284f5._.css",
      "static/chunks/node_modules_leaflet_dist_images_layers-2x_png_ba3284f5._.css",
      "static/chunks/node_modules_leaflet_dist_images_marker-icon_png_ba3284f5._.css",
      "static/chunks/node_modules_leaflet_dist_leaflet_b52d8e88.css"
    ]
  },
  "static/chunks/src_components_map_Map_jsx_93af1be8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/map/Map.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);