(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_598cbcb5.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_598cbcb5.js",
  "chunks": [
    "static/chunks/src_components_googlemaps_map_jsx_9969a7e0._.js",
    "static/chunks/node_modules_@mui_system_esm_e490fd74._.js",
    "static/chunks/node_modules_@mui_material_esm_6b82977d._.js",
    "static/chunks/node_modules_9c0059bb._.js",
    "static/chunks/src_dd4094c7._.js"
  ],
  "source": "dynamic"
});
