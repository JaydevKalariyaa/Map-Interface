(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_googlemaps_map_jsx_9969a7e0._.js", {

"[project]/src/components/googlemaps/map.jsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_28e78174._.js",
  "static/chunks/src_components_f34c30f7._.js",
  "static/chunks/src_components_googlemaps_map_jsx_5bdc2015._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/googlemaps/map.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);