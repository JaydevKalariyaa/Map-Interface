(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_map_Map_jsx_85fb8fc3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_map_Map_jsx_85fb8fc3._.js",
  "chunks": [
    "static/chunks/node_modules_8d444dc5._.js",
    "static/chunks/src_components_map_Map_jsx_df8be43f._.js",
    "static/chunks/node_modules_leaflet_dist_eeb49e3b._.css"
  ],
  "source": "dynamic"
});
