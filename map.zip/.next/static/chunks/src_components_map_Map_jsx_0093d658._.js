(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_map_Map_jsx_0093d658._.js", {

"[project]/src/components/map/Map.jsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_a41ed958._.js",
  "static/chunks/src_components_map_4e8c8695._.js",
  {
    "path": "static/chunks/node_modules_leaflet_dist_eeb49e3b._.css",
    "included": [
      "[project]/node_modules/leaflet/dist/images/layers.png (static in css)",
      "[project]/node_modules/leaflet/dist/images/layers-2x.png (static in css)",
      "[project]/node_modules/leaflet/dist/images/marker-icon.png (static in css)",
      "[project]/node_modules/leaflet/dist/leaflet.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/node_modules_leaflet_dist_images_layers_png_ba3284f5._.css",
      "static/chunks/node_modules_leaflet_dist_images_layers-2x_png_ba3284f5._.css",
      "static/chunks/node_modules_leaflet_dist_images_marker-icon_png_ba3284f5._.css",
      "static/chunks/node_modules_leaflet_dist_leaflet_b52d8e88.css"
    ]
  },
  "static/chunks/src_components_map_Map_jsx_5bdc2015._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/map/Map.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);