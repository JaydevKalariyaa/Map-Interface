(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_googlemaps_map_jsx_5bdc2015._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_googlemaps_map_jsx_5bdc2015._.js",
  "chunks": [
    "static/chunks/node_modules_28e78174._.js",
    "static/chunks/src_components_f34c30f7._.js"
  ],
  "source": "dynamic"
});
