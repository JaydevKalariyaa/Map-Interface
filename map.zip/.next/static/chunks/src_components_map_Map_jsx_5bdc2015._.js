(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_map_Map_jsx_5bdc2015._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_map_Map_jsx_5bdc2015._.js",
  "chunks": [
    "static/chunks/node_modules_a41ed958._.js",
    "static/chunks/src_components_map_4e8c8695._.js",
    "static/chunks/node_modules_leaflet_dist_eeb49e3b._.css"
  ],
  "source": "dynamic"
});
