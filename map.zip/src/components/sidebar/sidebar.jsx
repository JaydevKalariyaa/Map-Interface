"use client";

import { useState } from "react";
import {
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Checkbox,
  Typography,
  Box,
  Divider,
} from "@mui/material";

import MenuIcon from "@mui/icons-material/Menu";
import CloseIcon from "@mui/icons-material/Close";
import AgricultureIcon from "@mui/icons-material/Agriculture";
import HomeWorkIcon from "@mui/icons-material/HomeWork";
import FactoryIcon from "@mui/icons-material/Factory";

const categories = [
  { name: "agricultural", icon: <AgricultureIcon /> },
  { name: "residential", icon: <HomeWorkIcon /> },
  { name: "industrial", icon: <FactoryIcon /> },
];

export default function Sidebar({ filters, setFilters }) {
  const [open, setOpen] = useState(true);

  const toggleFilter = (cat) => {
    setFilters(
      filters.includes(cat)
        ? filters.filter((f) => f !== cat)
        : [...filters, cat]
    );
  };

  const toggleDrawer = () => setOpen(!open);

  return (
    <>
      {/* Menu Icon Button when sidebar is closed */}
      {!open && (
        <IconButton
          onClick={toggleDrawer}
          sx={{
            position: "fixed",
            top: 16,
            left: 16,
            zIndex: 1300,
            backgroundColor: "#ffffff",
            boxShadow: 2,
            borderRadius: "50%",
            "&:hover": { backgroundColor: "#f3f4f6" },
          }}
        >
          <MenuIcon />
        </IconButton>
      )}

      <Drawer
        variant="persistent"
        anchor="left"
        open={open}
        sx={{
        //   width: 260,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: 260,
            boxSizing: "border-box",
            backgroundColor: "#f9fafb",
            boxShadow: "2px 0 12px rgba(0,0,0,0.1)",
          },
        }}
      >
        {/* Header with title and close button */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 2,
            py: 2,
            backgroundColor: "#2563eb",
            color: "#ffffff",
          }}
        >
          <Typography variant="h6" fontWeight="bold">
            Parcel Map
          </Typography>
          <IconButton
            onClick={toggleDrawer}
            sx={{ color: "#ffffff" }}
          >
            <CloseIcon />
          </IconButton>
        </Box>

        <Divider />

        {/* Filter List */}
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 1 }}>
            Filter by Category
          </Typography>
          <List>
            {categories.map((cat) => (
              <ListItem
                key={cat.name}
                onClick={() => toggleFilter(cat.name)}
                sx={{
                  borderRadius: 2,
                  mb: 1,
                  pl: 1,
                  "&:hover": { backgroundColor: "#e5e7eb" },
                  cursor: "pointer",
                }}
              >
                <ListItemIcon sx={{ minWidth: 36 }}>{cat.icon}</ListItemIcon>
                <Checkbox
                  edge="start"
                  checked={filters.includes(cat.name)}
                  tabIndex={-1}
                  disableRipple
                />
                <ListItemText
                  primary={cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}
                />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
}
