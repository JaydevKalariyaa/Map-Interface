"use client";

import {
  APIProvider,
  Map,
  ControlPosition,
  AdvancedMarker,
  MapControl
} from "@vis.gl/react-google-maps";

import { useState } from "react";
import ParcelPopupCard from "../../components/map/ParcelPopupCard";
import {Polygon} from "./polygon"
export default function GoogleMapComponent() {
  const center = { lat: 34.03185555334993, lng: -84.55514101758651 };

  const [selectedParcel, setSelectedParcel] = useState(null);

  // Polygon coordinates (converted to LatLng)
  const polygonPath = [
    { lat: 34.0320025, lng: -84.554619 },
    { lat: 34.0320035, lng: -84.5546725 },
    { lat: 34.0324385, lng: -84.554575 },
    { lat: 34.0326105, lng: -84.5556235 },
    { lat: 34.0324835, lng: -84.5556275 },
    { lat: 34.0320325, lng: -84.55564 },
    { lat: 34.0320175, lng: -84.55564 },
    { lat: 34.031948, lng: -84.5556395 },
    { lat: 34.031866, lng: -84.5556415 },
    { lat: 34.031781, lng: -84.5556465 },
    { lat: 34.0316995, lng: -84.555654 },
    { lat: 34.031615, lng: -84.5556645 },
    { lat: 34.031534, lng: -84.5556775 },
    { lat: 34.031453, lng: -84.555693 },
    { lat: 34.031372, lng: -84.555711 },
    { lat: 34.0312685, lng: -84.55563 },
    { lat: 34.031213, lng: -84.555375 },
    { lat: 34.031201, lng: -84.5553175 },
    { lat: 34.03119, lng: -84.555257 },
    { lat: 34.0311805, lng: -84.5551955 },
    { lat: 34.031173, lng: -84.555137 },
    { lat: 34.031167, lng: -84.555078 },
    { lat: 34.0311625, lng: -84.555016 },
    { lat: 34.0311595, lng: -84.554957 },
    { lat: 34.031158, lng: -84.554895 },
    { lat: 34.0311545, lng: -84.554636 },
    { lat: 34.0319205, lng: -84.554621 },
    { lat: 34.0320025, lng: -84.554619 }, // close the loop
  ];

  const parcelData = {
    lat: center.lat,
    lng: center.lng,
    properties: {
      category: "residential",
      owner: "Jane Doe",
      area: "4500 sqft",
      propertyType: "Single Family Home",
      address: "Chastain Meadows Pkwy NW, GA",
      lastUpdated: "2025-03-01",
      estimatedValue: "$550,000",
      image: "https://source.unsplash.com/600x400/?house",
    },
  };

  return (
    <APIProvider apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}>
      <div className="relative w-full h-screen">
        <Map
          center={center}
          zoom={17}
          mapId={"roadmap"}
          style={{ width: "100%", height: "100%" }}
          onClick={() => setSelectedParcel(null)}
        >
             <MapControl position={ControlPosition.RIGHT_TOP}>
        {/* Draw Polygon */}
        <Polygon
            paths={[polygonPath]}
            options={{
              fillColor: "#1E90FF",
              fillOpacity: 0.4,
              strokeColor: "#003366",
              strokeOpacity: 0.8,
              strokeWeight: 2,
            }}
            onClick={() => setSelectedParcel(parcelData)}
          />
      </MapControl>
        
        </Map>

        {/* Centered popup card */}
        {selectedParcel && (
          <div className="fixed top-1/2 left-1/2 z-[1000] -translate-x-1/2 -translate-y-1/2">
            <ParcelPopupCard
              feature={selectedParcel}
              setSelectedFeature={setSelectedParcel} // Pass the setter function to close the popup
             
            />
          </div>
        )}
      </div>
    </APIProvider>
  );
}
