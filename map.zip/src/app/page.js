// /app/page.js
"use client";

import dynamic from "next/dynamic";
import { useState } from "react";
import Sidebar from "../components/sidebar/sidebar";

// const Map = dynamic(() => import("../components/map/Map"), { ssr: false });
const Map = dynamic(() => import("../components/googlemaps/map"), { ssr: false });

export default function HomePage() {
  const [activeFilters, setActiveFilters] = useState(["agricultural", "residential", "industrial"]);
console.log(activeFilters)
  return (
    <div className="flex h-screen">
      <Sidebar filters={activeFilters} setFilters={setActiveFilters} />
      <Map filters={activeFilters} />
    </div>
  );
}